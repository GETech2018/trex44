﻿    /*
    ** Watch_Face_Editor tool v 18.1
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

// bande du soleil (compte a rebours, horaires, barre) et point de l'arc des temperatures min/max

const SOL_Y = 291
const HORAIRE_Y = 346
const HORAIRE_G = 107
const HORAIRE_D = 358
const BARRE_X0 = 104
const BARRE_X1 = 362
const BARRE_Y = 334
const BARRE_EP = 10
const POINT = 25
const TEMP_R = 184
const TEMP_A0 = -65
const TEMP_A1 = -24

const LARGEUR = { chiffre: 13, s_h: 16, espace: 6, u_chiffre: 13, u_colon: 7 }
const LIBELLE = {
  en: { lever: ["sun_lever_en.png", 120], coucher: ["sun_coucher_en.png", 113] },
  fr: { lever: ["sun_lever_fr.png", 131], coucher: ["sun_coucher_fr.png", 166] },
}

let solLigne = []
let solGauche = []
let solDroite = []
let solBarre = null
let solPoint = null
let tempPoint = null
let solTemps = null
let solMeteo = null

function solImage(y) {
  return hmUI.createWidget(hmUI.widget.IMG, { x: 0, y: y, src: "s_0.png", show_level: hmUI.show_level.ONLY_NORMAL })
}

function solCreer() {
  solBarre = hmUI.createWidget(hmUI.widget.FILL_RECT, {
    x: Math.round(BARRE_X0), y: Math.round(BARRE_Y - BARRE_EP / 2), w: Math.round(BARRE_EP), h: Math.round(BARRE_EP),
    radius: 5, color: 0x4ea6ff, show_level: hmUI.show_level.ONLY_NORMAL,
  })
  solPoint = hmUI.createWidget(hmUI.widget.IMG, { x: 0, y: BARRE_Y - POINT / 2, src: "point.png", show_level: hmUI.show_level.ONLY_NORMAL })
  tempPoint = hmUI.createWidget(hmUI.widget.IMG, { x: 0, y: 0, src: "point.png", show_level: hmUI.show_level.ONLY_NORMAL })
  for (let i = 0; i < 7; i++) solLigne.push(solImage(SOL_Y))
  for (let i = 0; i < 5; i++) solGauche.push(solImage(HORAIRE_Y))
  for (let i = 0; i < 5; i++) solDroite.push(solImage(HORAIRE_Y))
  solTemps = hmSensor.createSensor(hmSensor.id.TIME)
  solMeteo = hmSensor.createSensor(hmSensor.id.WEATHER)
  solTemps.addEventListener(solTemps.event.MINUTEEND, function () {
    solMaj()
    tempMaj()
  })
}

function solLangue() {
  try {
    return hmSetting.getLanguage() == 6 ? "fr" : "en"
  } catch (e) {
    return "en"
  }
}

// pose une suite [src, largeur] a partir de x (src vide = espace), cache le reste du lot
function solPoser(lot, y, morceaux, x) {
  let k = 0
  for (const m of morceaux) {
    if (m[0]) {
      lot[k].setProperty(hmUI.prop.MORE, { x: Math.round(x), y: y, src: m[0] })
      lot[k++].setProperty(hmUI.prop.VISIBLE, true)
    }
    x += m[1]
  }
  for (; k < lot.length; k++) lot[k].setProperty(hmUI.prop.VISIBLE, false)
}

function solLargeur(morceaux) {
  let w = 0
  for (const m of morceaux) w += m[1]
  return w
}

function solChiffres(texte, prefixe, largeur) {
  const out = []
  for (const c of texte) out.push(c == ":" ? ["u_colon.png", LARGEUR.u_colon] : [prefixe + c + ".png", largeur])
  return out
}

function solHoraire(minutes) {
  const m = ((minutes % 1440) + 1440) % 1440
  const h = Math.floor(m / 60)
  return (h < 10 ? "0" : "") + h + ":" + (m % 60 < 10 ? "0" : "") + (m % 60)
}

// lever et coucher du jour, lever du lendemain ; null sans meteo synchronisee
function solJournee() {
  const meteo = solMeteo.getForecastWeather()
  const marees = meteo && meteo.tideData
  if (!marees || !marees.count) return null
  const auj = marees.data[0]
  const dem = marees.count > 1 ? marees.data[1] : auj
  return {
    lever: auj.sunrise.hour * 60 + auj.sunrise.minute,
    coucher: auj.sunset.hour * 60 + auj.sunset.minute,
    leverDemain: dem.sunrise.hour * 60 + dem.sunrise.minute + 1440,
  }
}

function solCacher() {
  for (const w of solLigne.concat(solGauche, solDroite, [solBarre, solPoint])) w.setProperty(hmUI.prop.VISIBLE, false)
}

function solMaj() {
  const j = solJournee()
  if (!j) {
    solCacher()
    return
  }
  const now = solTemps.hour * 60 + solTemps.minute
  // avant le lever, le coucher de la veille est pris a la meme heure qu'aujourd'hui
  let avant = j.coucher - 1440
  let apres = j.lever
  let cible = "lever"
  if (now >= j.coucher) {
    avant = j.coucher
    apres = j.leverDemain
  } else if (now >= j.lever) {
    avant = j.lever
    apres = j.coucher
    cible = "coucher"
  }
  const reste = apres - now
  const h = Math.floor(reste / 60)
  const libelle = LIBELLE[solLangue()][cible]
  // "8H 05" : heures toujours affichees, minutes sur deux chiffres
  const mn = reste % 60
  const ligne = [libelle, ["", LARGEUR.espace]].concat(solChiffres(String(h), "s_", LARGEUR.chiffre),
    [["s_h.png", LARGEUR.s_h], ["", LARGEUR.espace]], solChiffres((mn < 10 ? "0" : "") + mn, "s_", LARGEUR.chiffre))
  solPoser(solLigne, SOL_Y, ligne, 233 - solLargeur(ligne) / 2)

  const gauche = solChiffres(solHoraire(avant), "u_", LARGEUR.u_chiffre)
  const droite = solChiffres(solHoraire(apres), "u_", LARGEUR.u_chiffre)
  solPoser(solGauche, HORAIRE_Y, gauche, HORAIRE_G)
  solPoser(solDroite, HORAIRE_Y, droite, HORAIRE_D - solLargeur(droite))

  const p = Math.max(0, Math.min(1, (now - avant) / (apres - avant)))
  const course = BARRE_X1 - BARRE_X0 - BARRE_EP
  const cx = BARRE_X0 + BARRE_EP / 2 + p * course
  solBarre.setProperty(hmUI.prop.MORE, {
    x: Math.round(BARRE_X0), y: Math.round(BARRE_Y - BARRE_EP / 2), w: Math.round(Math.max(BARRE_EP, cx - BARRE_X0)),
    h: Math.round(BARRE_EP), radius: 5, color: 0x4ea6ff,
  })
  solPoint.setProperty(hmUI.prop.MORE, { x: Math.round(cx - POINT / 2), y: BARRE_Y - POINT / 2, src: "point.png" })
  solBarre.setProperty(hmUI.prop.VISIBLE, true)
  solPoint.setProperty(hmUI.prop.VISIBLE, true)
}

// point sur l'arc : temperature actuelle entre le minimum (bas) et le maximum (haut) du jour
function tempMaj() {
  const meteo = solMeteo.getForecastWeather()
  const prev = meteo && meteo.forecastData
  const actuelle = solMeteo.current
  if (!prev || !prev.count || actuelle == undefined) {
    tempPoint.setProperty(hmUI.prop.VISIBLE, false)
    return
  }
  const j = prev.data[0]
  const p = j.high > j.low ? Math.max(0, Math.min(1, (actuelle - j.low) / (j.high - j.low))) : 0.5
  const a = ((TEMP_A0 + p * (TEMP_A1 - TEMP_A0)) * Math.PI) / 180
  const x = 233 + TEMP_R * Math.sin(a) - POINT / 2
  const y = 233 - TEMP_R * Math.cos(a) - POINT / 2
  tempPoint.setProperty(hmUI.prop.MORE, { x: Math.round(x), y: Math.round(y), src: "point.png" })
  tempPoint.setProperty(hmUI.prop.VISIBLE, true)
}
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_training_load_image_progress_img_level = ''
        let normal_step_image_progress_img_progress = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_TextCircle = new Array(5);
        let normal_step_TextCircle_ASCIIARRAY = new Array(10);
        let normal_step_TextCircle_img_width = 13;
        let normal_step_TextCircle_img_height = 23;
        let normal_distance_TextCircle = new Array(5);
        let normal_distance_TextCircle_ASCIIARRAY = new Array(10);
        let normal_distance_TextCircle_img_width = 13;
        let normal_distance_TextCircle_img_height = 23;
        let normal_distance_TextCircle_unit = null;
        let normal_distance_TextCircle_unit_width = 39;
        let normal_distance_TextCircle_dot_width = 7;
        let normal_bio_charge_image_progress_img_progress = ''
        let normal_bio_charge_pointer_progress_img_pointer = ''
        let normal_bio_charge_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_temperature_high_TextCircle = new Array(4);
        let normal_temperature_high_TextCircle_ASCIIARRAY = new Array(10);
        let normal_temperature_high_TextCircle_img_width = 10;
        let normal_temperature_high_TextCircle_img_height = 18;
        let normal_temperature_high_TextCircle_unit = null;
        let normal_temperature_high_TextCircle_unit_width = 7;
        let normal_temperature_high_TextCircle_dot_width = 6;
        let normal_temperature_low_TextCircle = new Array(4);
        let normal_temperature_low_TextCircle_ASCIIARRAY = new Array(10);
        let normal_temperature_low_TextCircle_img_width = 10;
        let normal_temperature_low_TextCircle_img_height = 18;
        let normal_temperature_low_TextCircle_unit = null;
        let normal_temperature_low_TextCircle_unit_width = 7;
        let normal_temperature_low_TextCircle_dot_width = 6;
        let normal_temperature_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_temperature_current_text_img = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_trainingLoad_jumpable_img_click = ''
        let normal_recoveryTime_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'fond.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'statique_en.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_training_load_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 6,
              y: 120,
              image_array: ["charge_1.png","charge_2.png","charge_3.png"],
              image_length: 3,
              type: hmUI.data_type.TRAINING_LOAD,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_progress = hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
              x: [389,386,383,380,377,373,369,364,360,355,350,346,341,336,330,325,319,314,308,300],
              y: [143,137,131,125,120,115,110,104,99,94,90,85,82,77,73,70,66,63,59,56],
              image_array: ["pas_01.png","pas_02.png","pas_03.png","pas_04.png","pas_05.png","pas_06.png","pas_07.png","pas_08.png","pas_09.png","pas_10.png","pas_11.png","pas_12.png","pas_13.png","pas_14.png","pas_15.png","pas_16.png","pas_17.png","pas_18.png","pas_19.png","pas_20.png"],
              image_length: 20,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
normal_step_image_progress_img_progress.setProperty(hmUI.prop.VISIBLE, false);

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'ptr_pas.png',
              center_x: 233,
              center_y: 233,
              x: 13,
              y: 197,
              start_angle: 65,
              end_angle: 24,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["c_0.png","c_1.png","c_2.png","c_3.png","c_4.png","c_5.png","c_6.png","c_7.png","c_8.png","c_9.png"],
              // radius: 202,
              // angle: 35,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextCircle_ASCIIARRAY[0] = 'c_0.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[1] = 'c_1.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[2] = 'c_2.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[3] = 'c_3.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[4] = 'c_4.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[5] = 'c_5.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[6] = 'c_6.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[7] = 'c_7.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[8] = 'c_8.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[9] = 'c_9.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 5; i++) {
              normal_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_step_TextCircle_img_width / 2 + 22,
                pos_y: 233 - 225 + 1,
                src: 'c_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            // normal_distance_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["c_0.png","c_1.png","c_2.png","c_3.png","c_4.png","c_5.png","c_6.png","c_7.png","c_8.png","c_9.png"],
              // radius: 202,
              // angle: -42,
              // char_space_angle: 0,
              // unit: 'c_km.png',
              // dot_image: 'c_dot.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_distance_TextCircle_ASCIIARRAY[0] = 'c_0.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[1] = 'c_1.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[2] = 'c_2.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[3] = 'c_3.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[4] = 'c_4.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[5] = 'c_5.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[6] = 'c_6.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[7] = 'c_7.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[8] = 'c_8.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[9] = 'c_9.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 5; i++) {
              normal_distance_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_distance_TextCircle_img_width / 2,
                pos_y: 233 - 225,
                src: 'c_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_distance_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              center_x: 233,
              center_y: 233,
              pos_x: 233 - normal_distance_TextCircle_unit_width / 2,
              pos_y: 233 - 225,
              src: 'c_km.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);

            const mileageUnit = hmSetting.getMileageUnit();            //#endregion
            
            const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
            distance.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_bio_charge_image_progress_img_progress = hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
              x: [137,149,157,166,175,183,193,202,212,221,230,239,249,257,266,275,283,292,301,309],
              y: [416,419,423,425,428,430,432,433,434,435,435,434,433,432,430,428,425,422,419,416],
              image_array: ["hyb_01.png","hyb_02.png","hyb_03.png","hyb_04.png","hyb_05.png","hyb_06.png","hyb_07.png","hyb_08.png","hyb_09.png","hyb_10.png","hyb_11.png","hyb_12.png","hyb_13.png","hyb_14.png","hyb_15.png","hyb_16.png","hyb_17.png","hyb_18.png","hyb_19.png","hyb_20.png"],
              image_length: 20,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
normal_bio_charge_image_progress_img_progress.setProperty(hmUI.prop.VISIBLE, false);

            normal_bio_charge_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'ptr_hyb.png',
              center_x: 233,
              center_y: 233,
              x: 13,
              y: 222,
              start_angle: 205,
              end_angle: 155,
              invalid_visible: false,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 191,
              y: 389,
              font_array: ["x_0.png","x_1.png","x_2.png","x_3.png","x_4.png","x_5.png","x_6.png","x_7.png","x_8.png","x_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'x_pct.png',
              unit_tc: 'x_pct.png',
              unit_en: 'x_pct.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 241,
              y: 125,
              font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'v_pct.png',
              unit_tc: 'v_pct.png',
              unit_en: 'v_pct.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 178,
              y: 49,
              week_en: ["day_en_01.png","day_en_02.png","day_en_03.png","day_en_04.png","day_en_05.png","day_en_06.png","day_en_07.png"],
              week_tc: ["day_en_01.png","day_en_02.png","day_en_03.png","day_en_04.png","day_en_05.png","day_en_06.png","day_en_07.png"],
              week_sc: ["day_en_01.png","day_en_02.png","day_en_03.png","day_en_04.png","day_en_05.png","day_en_06.png","day_en_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 248,
              day_startY: 49,
              day_sc_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              day_tc_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              day_en_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_temperature_high_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
              // radius: 157,
              // angle: -30,
              // char_space_angle: 0,
              // unit: 't_deg.png',
              // dot_image: 't_minus.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.WEATHER_HIGH,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_temperature_high_TextCircle_ASCIIARRAY[0] = 't_0.png';  // set of images with numbers
            normal_temperature_high_TextCircle_ASCIIARRAY[1] = 't_1.png';  // set of images with numbers
            normal_temperature_high_TextCircle_ASCIIARRAY[2] = 't_2.png';  // set of images with numbers
            normal_temperature_high_TextCircle_ASCIIARRAY[3] = 't_3.png';  // set of images with numbers
            normal_temperature_high_TextCircle_ASCIIARRAY[4] = 't_4.png';  // set of images with numbers
            normal_temperature_high_TextCircle_ASCIIARRAY[5] = 't_5.png';  // set of images with numbers
            normal_temperature_high_TextCircle_ASCIIARRAY[6] = 't_6.png';  // set of images with numbers
            normal_temperature_high_TextCircle_ASCIIARRAY[7] = 't_7.png';  // set of images with numbers
            normal_temperature_high_TextCircle_ASCIIARRAY[8] = 't_8.png';  // set of images with numbers
            normal_temperature_high_TextCircle_ASCIIARRAY[9] = 't_9.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 4; i++) {
              normal_temperature_high_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_temperature_high_TextCircle_img_width / 2,
                pos_y: 233 - 175,
                src: 't_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_temperature_high_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_temperature_high_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              center_x: 233,
              center_y: 233,
              pos_x: 233 - normal_temperature_high_TextCircle_unit_width / 2,
              pos_y: 233 - 175,
              src: 't_deg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_temperature_high_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion
            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            // normal_temperature_low_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 233,
              // circle_center_Y: 233,
              // font_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
              // radius: 157,
              // angle: -62,
              // char_space_angle: 0,
              // unit: 't_deg.png',
              // dot_image: 't_minus.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.WEATHER_LOW,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_temperature_low_TextCircle_ASCIIARRAY[0] = 't_0.png';  // set of images with numbers
            normal_temperature_low_TextCircle_ASCIIARRAY[1] = 't_1.png';  // set of images with numbers
            normal_temperature_low_TextCircle_ASCIIARRAY[2] = 't_2.png';  // set of images with numbers
            normal_temperature_low_TextCircle_ASCIIARRAY[3] = 't_3.png';  // set of images with numbers
            normal_temperature_low_TextCircle_ASCIIARRAY[4] = 't_4.png';  // set of images with numbers
            normal_temperature_low_TextCircle_ASCIIARRAY[5] = 't_5.png';  // set of images with numbers
            normal_temperature_low_TextCircle_ASCIIARRAY[6] = 't_6.png';  // set of images with numbers
            normal_temperature_low_TextCircle_ASCIIARRAY[7] = 't_7.png';  // set of images with numbers
            normal_temperature_low_TextCircle_ASCIIARRAY[8] = 't_8.png';  // set of images with numbers
            normal_temperature_low_TextCircle_ASCIIARRAY[9] = 't_9.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 4; i++) {
              normal_temperature_low_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                center_x: 233,
                center_y: 233,
                pos_x: 233 - normal_temperature_low_TextCircle_img_width / 2,
                pos_y: 233 - 175,
                src: 't_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_temperature_low_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_temperature_low_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              center_x: 233,
              center_y: 233,
              pos_x: 233 - normal_temperature_low_TextCircle_unit_width / 2,
              pos_y: 233 - 175,
              src: 't_deg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_temperature_low_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 132,
              y: 125,
              font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'v_deg.png',
              unit_tc: 'v_deg.png',
              unit_en: 'v_deg.png',
              negative_image: 'v_minus.png',
              invalid_image: 'v_null.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 50,
              hour_startY: 177,
              hour_array: ["h_0.png","h_1.png","h_2.png","h_3.png","h_4.png","h_5.png","h_6.png","h_7.png","h_8.png","h_9.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 241,
              minute_startY: 177,
              minute_array: ["m_0.png","m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
solCreer()
solMaj()
tempMaj()
            // end user_script.js


            console.log('Watch_Face.ScreenAOD');

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 241,
              y: 302,
              font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'v_pct.png',
              unit_tc: 'v_pct.png',
              unit_en: 'v_pct.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 178,
              y: 107,
              week_en: ["day_en_01.png","day_en_02.png","day_en_03.png","day_en_04.png","day_en_05.png","day_en_06.png","day_en_07.png"],
              week_tc: ["day_en_01.png","day_en_02.png","day_en_03.png","day_en_04.png","day_en_05.png","day_en_06.png","day_en_07.png"],
              week_sc: ["day_en_01.png","day_en_02.png","day_en_03.png","day_en_04.png","day_en_05.png","day_en_06.png","day_en_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 248,
              day_startY: 107,
              day_sc_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              day_tc_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              day_en_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 132,
              y: 302,
              font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'v_deg.png',
              unit_tc: 'v_deg.png',
              unit_en: 'v_deg.png',
              negative_image: 'v_minus.png',
              invalid_image: 'v_null.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 50,
              hour_startY: 177,
              hour_array: ["h_0.png","h_1.png","h_2.png","h_3.png","h_4.png","h_5.png","h_6.png","h_7.png","h_8.png","h_9.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 241,
              minute_startY: 177,
              minute_array: ["m_0.png","m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 320,
              y: 39,
              w: 97,
              h: 87,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 237,
              y: 97,
              w: 94,
              h: 68,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 126,
              y: 287,
              w: 214,
              h: 58,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 236,
              y: 171,
              w: 178,
              h: 115,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_trainingLoad_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 25,
              y: 306,
              w: 101,
              h: 125,
              type: hmUI.data_type.TRAINING_LOAD,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_recoveryTime_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 341,
              y: 306,
              w: 97,
              h: 129,
              type: hmUI.data_type.RECOVERY_TIME,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 175,
              y: 43,
              w: 117,
              h: 39,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 176,
              y: 357,
              w: 117,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BioChargeHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 120,
              y: 90,
              w: 105,
              h: 75,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 50,
              y: 170,
              w: 180,
              h: 116,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            //#region text_update
            function text_update() {
              console.log('text_update()');

              console.log('update text circle step_STEP');
              let valueStep = step.current;
              let normal_step_circle_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 35;
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_circle_string.length > 0 && normal_step_circle_string.length <= 5) {  // display data if it was possible to get it
                  let normal_step_TextCircle_img_angle = 0;
                  let normal_step_TextCircle_dot_img_angle = 0;
                  normal_step_TextCircle_img_angle = toDegree(Math.atan2(normal_step_TextCircle_img_width/2, 202));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_step_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_step_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_step_TextCircle_img_width / 2 + 22);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.SRC, normal_step_TextCircle_ASCIIARRAY[charCode]);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_step_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle DISTANCE');
              let distanceCurrent = distance.current;
              let normal_distance_circle_string = (distanceCurrent / 1000).toFixed(2);
              if (mileageUnit == 1) normal_distance_circle_string = (0.621371 * distanceCurrent / 1000).toFixed(2);

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = -42;
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && normal_distance_circle_string.length > 0 && normal_distance_circle_string.length <= 5) {  // display data if it was possible to get it
                  let normal_distance_TextCircle_img_angle = 0;
                  let normal_distance_TextCircle_dot_img_angle = 0;
                  let normal_distance_TextCircle_unit_angle = 0;
                  normal_distance_TextCircle_img_angle = toDegree(Math.atan2(normal_distance_TextCircle_img_width/2, 202));
                  normal_distance_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_distance_TextCircle_dot_width/2, 202));
                  normal_distance_TextCircle_unit_angle = toDegree(Math.atan2(normal_distance_TextCircle_unit_width/2, 202));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_distance_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_distance_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_distance_TextCircle_img_width / 2);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.SRC, normal_distance_TextCircle_ASCIIARRAY[charCode]);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_distance_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += normal_distance_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_distance_TextCircle_dot_width / 2);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.SRC, 'c_dot.png');
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_distance_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle += normal_distance_TextCircle_unit_angle;
                  normal_distance_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };
              let weatherData = weatherSensor.getForecastWeather();
              let forecastData = weatherData.forecastData;
              let temperature_high_temp = -100;
              if (forecastData.count > 0) {
                temperature_high_temp = forecastData.data[0].high;
              }; // end forecastData;

              console.log('update text circle temperature_high_forecastData');
              let temperatureHigh = undefined;
              let normal_temperature_high_circle_string = undefined;
              if (temperature_high_temp > -100) {
                temperatureHigh = 0;
                normal_temperature_high_circle_string = String(temperature_high_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_temperature_high_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_temperature_high_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = -30;
                if (temperatureHigh != null && temperatureHigh != undefined && isFinite(temperatureHigh) && normal_temperature_high_circle_string.length > 0 && normal_temperature_high_circle_string.length <= 4) {  // display data if it was possible to get it
                  let normal_temperature_high_TextCircle_img_angle = 0;
                  let normal_temperature_high_TextCircle_dot_img_angle = 0;
                  let normal_temperature_high_TextCircle_unit_angle = 0;
                  normal_temperature_high_TextCircle_img_angle = toDegree(Math.atan2(normal_temperature_high_TextCircle_img_width/2, 157));
                  normal_temperature_high_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_temperature_high_TextCircle_dot_width/2, 157));
                  normal_temperature_high_TextCircle_unit_angle = toDegree(Math.atan2(normal_temperature_high_TextCircle_unit_width/2, 157));
                  // alignment = CENTER_H
                  let normal_temperature_high_TextCircle_angleOffset = normal_temperature_high_TextCircle_img_angle * (normal_temperature_high_circle_string.length - 1);
                  normal_temperature_high_TextCircle_angleOffset = normal_temperature_high_TextCircle_angleOffset + (normal_temperature_high_TextCircle_img_angle + normal_temperature_high_TextCircle_unit_angle + 0) / 2;
                  char_Angle -= normal_temperature_high_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_temperature_high_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_temperature_high_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_temperature_high_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_temperature_high_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_temperature_high_TextCircle_img_width / 2);
                      normal_temperature_high_TextCircle[index].setProperty(hmUI.prop.SRC, normal_temperature_high_TextCircle_ASCIIARRAY[charCode]);
                      normal_temperature_high_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_temperature_high_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += normal_temperature_high_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_temperature_high_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_temperature_high_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_temperature_high_TextCircle_dot_width / 2);
                      normal_temperature_high_TextCircle[index].setProperty(hmUI.prop.SRC, 't_minus.png');
                      normal_temperature_high_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_temperature_high_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle += normal_temperature_high_TextCircle_unit_angle;
                  normal_temperature_high_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_temperature_high_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };
              let temperature_low_temp = -100;
              if (forecastData.count > 0) {
                temperature_low_temp = forecastData.data[0].low;
              }; // end forecastData;

              console.log('update text circle temperature_low_forecastData');
              let temperatureLow = undefined;
              let normal_temperature_low_circle_string = undefined;
              if (temperature_low_temp > -100) {
                temperatureLow = 0;
                normal_temperature_low_circle_string = String(temperature_low_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_temperature_low_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_temperature_low_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = -62;
                if (temperatureLow != null && temperatureLow != undefined && isFinite(temperatureLow) && normal_temperature_low_circle_string.length > 0 && normal_temperature_low_circle_string.length <= 4) {  // display data if it was possible to get it
                  let normal_temperature_low_TextCircle_img_angle = 0;
                  let normal_temperature_low_TextCircle_dot_img_angle = 0;
                  let normal_temperature_low_TextCircle_unit_angle = 0;
                  normal_temperature_low_TextCircle_img_angle = toDegree(Math.atan2(normal_temperature_low_TextCircle_img_width/2, 157));
                  normal_temperature_low_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_temperature_low_TextCircle_dot_width/2, 157));
                  normal_temperature_low_TextCircle_unit_angle = toDegree(Math.atan2(normal_temperature_low_TextCircle_unit_width/2, 157));
                  // alignment = CENTER_H
                  let normal_temperature_low_TextCircle_angleOffset = normal_temperature_low_TextCircle_img_angle * (normal_temperature_low_circle_string.length - 1);
                  normal_temperature_low_TextCircle_angleOffset = normal_temperature_low_TextCircle_angleOffset + (normal_temperature_low_TextCircle_img_angle + normal_temperature_low_TextCircle_unit_angle + 0) / 2;
                  char_Angle -= normal_temperature_low_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_temperature_low_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_temperature_low_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_temperature_low_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_temperature_low_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_temperature_low_TextCircle_img_width / 2);
                      normal_temperature_low_TextCircle[index].setProperty(hmUI.prop.SRC, normal_temperature_low_TextCircle_ASCIIARRAY[charCode]);
                      normal_temperature_low_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_temperature_low_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += normal_temperature_low_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_temperature_low_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_temperature_low_TextCircle[index].setProperty(hmUI.prop.POS_X, 233 - normal_temperature_low_TextCircle_dot_width / 2);
                      normal_temperature_low_TextCircle[index].setProperty(hmUI.prop.SRC, 't_minus.png');
                      normal_temperature_low_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_temperature_low_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle += normal_temperature_low_TextCircle_unit_angle;
                  normal_temperature_low_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_temperature_low_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();

                console.log('resume_call.js');
                // start resume_call.js

solMaj()
tempMaj()
                // end resume_call.js

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}